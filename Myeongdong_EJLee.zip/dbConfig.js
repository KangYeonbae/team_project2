// dbConfig.js
module.exports = {
    user: 'open_source',
    password: '1111',
    connectString: 'localhost:1521/xe'
};